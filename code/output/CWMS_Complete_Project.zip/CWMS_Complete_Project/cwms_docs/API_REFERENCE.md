# CWMS API Reference

Base URL: `http://127.0.0.1:8000`

Interactive schema: `/docs`. All responses are JSON unless stated.

## Safety and authentication

The server binds to `127.0.0.1` by default. A non-loopback bind is refused
unless `CWMS_API_TOKEN` is configured or
`CWMS_ALLOW_UNAUTHENTICATED_REMOTE=1` is explicitly set for an isolated demo.

When `CWMS_API_TOKEN` is set, these state-changing endpoints require a bearer
token:

- `POST /api/simulation/start`
- `POST /api/scenarios/run`
- `POST /api/nodes/{node_name}/health`
- `POST /api/history/prune`

```http
Authorization: Bearer <CWMS_API_TOKEN>
```

A missing or wrong token returns `401` with `WWW-Authenticate: Bearer`. Read-only
endpoints and the dashboard remain public. CORS is disabled unless
`CWMS_CORS_ORIGINS` contains a comma-separated allowlist. Request bodies over
32 KiB return `413`. Security headers (`X-Content-Type-Options: nosniff`,
`X-Frame-Options: DENY`, `Referrer-Policy: no-referrer`) are added to responses.

This is a local demonstration service, not an internet-facing security boundary.
Do not expose it without an external gateway, TLS, and a real identity provider.

## Health and configuration

### `GET /health`

```json
{"status": "healthy", "service": "CWMS API"}
```

### `GET /api/config`

Returns default simulation parameters, available policies/scenarios, and limits.

```json
{
  "policy": "least-loaded",
  "intervals": 20,
  "base_rate": 40,
  "burst_rate": 140,
  "burst_start": 8,
  "burst_end": 13,
  "surge_threshold": 90,
  "load_threshold": 80.0,
  "max_load_threshold": 100.0,
  "fail_node": null,
  "forecast_window": 5,
  "forecast_strategy": "change_aware",
  "admission_control": true,
  "overload_threshold": 100.0,
  "queue_limit": 50,
  "request_timeout_ms": 2000.0,
  "available_forecast_strategies": ["moving_average", "change_aware"],
  "available_policies": ["round-robin", "least-loaded", "fcfs", "adaptive"],
  "available_scenarios": ["normal", "burst", "failure", "overload"],
  "max_total_requests": 100000,
  "max_request_bytes": 32768,
  "auth_required": false
}
```

## Simulations

### `POST /api/simulation/start`

Request body:

```json
{
  "policy": "least-loaded",
  "intervals": 20,
  "base_rate": 40,
  "burst_rate": 140,
  "burst_start": 8,
  "burst_end": 13,
  "surge_threshold": 90,
  "load_threshold": 80.0,
  "max_load_threshold": 100.0,
  "fail_node": null,
  "forecast_window": 5,
  "forecast_strategy": "change_aware",
  "admission_control": true,
  "overload_threshold": 100.0,
  "queue_limit": 50,
  "request_timeout_ms": 2000.0,
  "seed": 7
}
```

Validation:

- `policy` in `round-robin | least-loaded | fcfs | adaptive` (422 otherwise).
- `forecast_strategy` in `moving_average | change_aware` (422 otherwise).
- `fail_node` must be a known node name or `null` (422 otherwise).
- `intervals` 1-200; `base_rate`/`burst_rate` 1-1000; `forecast_window` 1-50;
  `max_load_threshold` 0-300; `overload_threshold` 0-150; `queue_limit` 0-1000;
  `request_timeout_ms` 0-600000 (exclusive of zero); non-negative seed.
- `intervals * max(base_rate, burst_rate) <= 100000` (422 otherwise).
- `burst_start > burst_end` -> 400.
- `burst_end > intervals` -> 400.
- `burst_start == burst_end` disables the burst window.
- A run already active -> 409.

Admission control semantics:

- Below the node's `overload_threshold`, a request is accepted immediately.
- At or above it, a request waits in a per-node queue of at most `queue_limit`
  requests. A full queue rejects the request as overload.
- Requests are accepted, queued, overflow-rejected, or rejected because no
  healthy node exists.
- Queued requests drain at the end of the interval. Estimated wait is
  `1000 / max(1, capacity) * position + simulated latency`; a wait over
  `request_timeout_ms` fails as a timeout and is never counted as completed.
- Setting `admission_control=false` restores the unbounded legacy path where all
  requests assigned to healthy nodes are completed immediately.

Response `200`:

```json
{"message": "Simulation started", "intervals": 20, "policy": "least-loaded"}
```

The run executes in a background thread; poll status. Local runs typically finish
in well under a second.

### `GET /api/simulation/status`

```json
{
  "interval": 20,
  "total_intervals": 20,
  "running": false,
  "policy": "least-loaded",
  "requests_generated": 770,
  "requests_assigned": 770,
  "requests_rejected": 0,
  "requests_completed": 770,
  "requests_failed": 0,
  "requests_queued": 0,
  "requests_timed_out": 0,
  "requests_rejected_overload": 0,
  "requests_rejected_no_capacity": 0,
  "surge_detected": true,
  "forecast": 38.4,
  "recommendation": "No capacity action indicated by current rules",
  "nodes": [
    {
      "name": "backend-a",
      "capacity": 100.0,
      "load": 0.0,
      "healthy": true,
      "state": "healthy",
      "assigned": 279,
      "available_capacity": 100.0,
      "overload_threshold": 100.0,
      "queue_limit": 50,
      "queued_current": 0,
      "queued_total": 279,
      "queue_overflow_total": 0,
      "max_queue_depth": 1
    }
  ],
  "error": null,
  "run_id": 1,
  "label": "custom"
}
```

`requests_assigned` counts all admitted requests, including those that waited in
a queue. It is kept for compatibility and equals `requests_accepted` in the
summary. Invariants:

```text
generated = assigned + rejected
assigned  = completed + failed
rejected  = rejected_overload + rejected_no_capacity
failed    = timed_out (currently the only failure reason)
```

### `GET /api/simulation/results`

Returns per-interval records with `surge_event`, `forecast`, `recommendation`,
`max_load`, and per-node snapshots. Interval records include
`requests_completed`, `requests_failed`, `requests_timed_out`,
`requests_queued`, `requests_rejected_overload`, and
`requests_rejected_no_capacity`. `404` if no run has completed.

### `GET /api/simulation/summary`

Returns `config`, `system_metrics`, `node_metrics`, `surge_events`,
`forecast_accuracy` (`mae`, `rmse`, `ma_mae`, `ma_rmse`, `naive_mae`,
`naive_rmse`, `strategy`), and the final recommendation. `404` if no run has
completed. System metrics include `total_requests_accepted`, completed, failed,
queued, timed-out, rejection-reason counts, and acceptance/completion/rejection/
failure/queue/timeout rates.

## Scenarios

### `POST /api/scenarios/run`

```json
{"scenario": "overload", "policy": "adaptive"}
```

Scenarios:

| ID | Base | Burst | Failure / admission |
|---|---|---|---|
| `normal` | 40 | none | none |
| `burst` | 40 | 180 on intervals 8-12 | none |
| `failure` | 50 | none | `backend-b` unhealthy |
| `overload` | 120 | none | threshold 80, queue 10, timeout 100 ms |

Response `200` with message; `422` for an unknown scenario/policy; `409` if busy;
`401` if auth is enabled and the token is missing/wrong.

### `GET /api/scenarios`

Lists scenario metadata and available policies.

## Nodes

### `GET /api/nodes`

Current node snapshots, including admission settings, current queue depth,
queued total, overflow total, and maximum observed queue depth.

### `POST /api/nodes/{node_name}/health?healthy=false`

Sets a node unhealthy (or healthy with `healthy=true`) while no run is active.
The setting is stored as an override and applied to subsequent simulations.
A scenario's own failure configuration still forces its node unhealthy. Returns
`409` during a run and `404` for an unknown node. Token-protected when auth is
enabled.

## Exports

### `GET /api/export/csv`

Downloads the latest completed run as `cwms_results.csv`. `404` if no result.
Columns include interval, policy, request counts (accepted, queued, completed,
failed, timed-out, rejected and rejection reasons), node, health, load, surge,
selected forecast (`forecast_predicted`/`forecast_method`), pure moving-average
forecast (`ma_predicted`), naive forecast, recommendation, and forecast error.

### `GET /api/export/json`

Returns the latest summary as JSON. `404` if no result.

## History (SQLite)

### `GET /api/history?limit=20`

`limit` must be 1-200 (400 otherwise). Returns newest-first run summaries.

### `GET /api/history/{run_id}`

Returns the run, interval metrics, and node metrics. `404` if unknown.

### `POST /api/history/prune`

Token-protected when auth is enabled.

```json
{"keep_latest": 50}
```

Deletes older runs and their cascaded metric rows. Returns `deleted`,
`remaining`, `previous`, and `keep_latest`. `keep_latest` may be 0-10000.

## Dashboard

### `GET /dashboard`

Serves `cwms_dashboard/index.html`. Assets are mounted at `/static/`. The header
includes an optional API-token field; the value is kept in browser session
storage and sent only to protected POST endpoints.

## Error format

FastAPI standard:

```json
{"detail": "burst_end cannot exceed intervals"}
```

Pydantic validation errors return `422` with a `detail` array. Oversized bodies
return:

```json
{"detail": "Request body too large"}
```

## HTTP status summary

| Code | Meaning |
|---|---|
| 200 | Success |
| 400 | Semantically invalid configuration or history limit |
| 401 | Missing/invalid bearer token |
| 404 | Missing result/run/node/dashboard |
| 409 | Simulation already running or node edit during a run |
| 413 | Request body over 32 KiB |
| 422 | Schema/validation failure |
