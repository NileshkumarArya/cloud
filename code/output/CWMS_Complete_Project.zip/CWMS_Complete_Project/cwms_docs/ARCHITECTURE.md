# CWMS Architecture

## Scope

Local, single-process simulation of cloud workload routing with a REST API,
dashboard, CSV/JSON export, and versioned SQLite history. It includes bounded
admission queues, simulated request timeouts, and an optional shared-token guard.
It is not a production load balancer, autoscaler, or cloud-provider integration.

## Components

| Component | Module | Responsibility |
|---|---|---|
| Node model | `cwms_simulator/nodes.py` | Capacity, load, health, assignment counters, bounded queue admission |
| Traffic generator | `cwms_simulator/traffic_generator.py` | Reproducible synthetic rates with optional burst window |
| Scheduling | `cwms_simulator/policies.py` | Health-aware node selection |
| Admission / metrics | `cwms_simulator/metrics.py` | Accepted, queued, completed, failed/timed-out, and rejection-reason counters |
| Surge detection | `cwms_simulator/surge_detector.py` | Rate, average-load, and maximum-node-load thresholds with cooldown |
| Forecasting | `cwms_simulator/forecaster.py` | Causal moving average / change-aware strategies plus MAE/RMSE |
| Recommendations | `cwms_simulator/recommendations.py` | Transparent rule-based advice |
| Orchestration | `cwms_simulator/simulator.py` | Interval loop, admission, queue drain, results, CSV/JSON |
| Persistence | `cwms_simulator/storage.py` | Schema-v2 SQLite run/interval/node tables, migration, pruning |
| CLI | `cwms_simulator/cli.py` | Local experiments and admission options |
| API | `cwms_api/main.py` | Run control, status, exports, history, auth, static dashboard |
| Dashboard | `cwms_dashboard/` | Overview, nodes, metrics, forecast, scenarios, token entry |

## Simulation loop (per interval)

1. Generate requests from the configured rate (+/-10% seeded variation).
2. Decay each node's load by 0.55.
3. For each request, ask the policy for a healthy node. No healthy node ->
   rejected with reason `no_capacity`.
4. Apply admission control on the selected node:
   - load below `overload_threshold`: accept immediately and complete;
   - load at/above threshold and queue not full: admit to the per-interval queue;
   - queue full: reject with reason `overload`.
5. Increase the node's load and record the admission.
6. Drain each node's queue at the end of the interval. Estimated wait is
   `1000 / max(1, capacity) * position + simulated latency`; requests over
   `request_timeout_ms` fail as `timeout`, the rest complete with that latency.
7. Check surge detection using this interval's request count and average/maximum
   node loads.
8. Produce a forecast from observations **before** this interval, then store the
   actual value for evaluation. The default `change_aware` strategy uses the
   moving average unless the recent spread exceeds 20% of its mean.
9. Evaluate recommendations.
10. Sync node health/load snapshots and finalise interval counters.

## Load and admission model

Each admitted request adds `3.0 * 100 / capacity` load percentage points, capped
at 150%. Latency estimate:

```text
latency_ms = 20 * (100 / capacity) * (1 + current_load / 100)
```

The queue is an intentionally simple per-interval model: it does not persist
across intervals and does not model packet-level arrival order. Queue wait is
derived from node capacity and queue position. These constants are illustrative
simulation parameters, not calibrated production values.

Accounting invariants for a completed run:

```text
generated = assigned + rejected
assigned  = completed + failed
rejected  = rejected_overload + rejected_no_capacity
failed    = timed_out
```

`requests_assigned` and `requests_accepted` both count immediate plus queued
admissions; `requests_queued` is a subset of them.

## Policies

- **Round robin:** cycles through all configured nodes, skipping unhealthy ones.
- **Least loaded:** minimum current load among healthy nodes; equal-load ties
  resolve to the node with fewer prior assignments.
- **FCFS (extension):** first healthy node in configuration order.
- **Adaptive (extension):** computes remaining cluster headroom in requests. If
  the causal forecast exceeds that headroom, selects the healthy node with the
  most available capacity, breaking equal-headroom ties by fewer prior assignments;
  otherwise behaves as least-loaded.

All policies are deterministic for a fixed input sequence. Policies select on
load and health; queue depth is enforced by the node's admission step rather than
used as a separate routing score.

## Forecast

Two causal strategies are available:

- `moving_average`: mean of the last `forecast_window` *prior* observations.
- `change_aware` (default): if the spread of those observations exceeds 20% of
  their mean, use the latest observation and report `change_aware_last`;
  otherwise use the moving average.

The current interval is observed only after the forecast is recorded, so there is
no future information leakage. The first interval has no history and is excluded
from MAE/RMSE. Both the pure moving average (`ma_mae`/`ma_rmse`) and the causal
last-value naive baseline (`naive_mae`/`naive_rmse`) are scored on the same
intervals for comparison. Change-aware cannot anticipate the first interval of a
new regime; it reacts after the first changed observation.

## Surge detection

- Rate surge: average of the last N request counts >= `rate_threshold`.
- Average-load surge: average of the last N average node loads >=
  `load_threshold`.
- Maximum-load surge: average of the last N interval maximum node loads >=
  `max_load_threshold` (default 100%).
- Priority: rate, then maximum-load, then average-load.
- A 2-interval cooldown suppresses duplicate alerts.

The maximum-load rule addresses concentration that the cluster-average rule can
miss. For example, FCFS reaches 150% peak node load; it records 9 surge events in
a normal run where the average-only rule would record none.

## Persistence

`ResultsStore` creates schema version 2 on first use
(`PRAGMA foreign_keys = ON`, WAL journal mode). Existing v1 databases are
migrated in place by adding the admission/queue columns with safe defaults.
Completed API runs are written in a single transaction. History is newest-first
and can be pruned by the CLI/script or token-protected API. Child interval and
node rows cascade on delete.

## API hardening

- Default bind is loopback. A non-loopback bind requires `CWMS_API_TOKEN` or an
  explicit `CWMS_ALLOW_UNAUTHENTICATED_REMOTE=1` override.
- Optional bearer token (constant-time comparison) protects all state-changing
  POST endpoints.
- Request bodies are limited to 32 KiB, including chunked requests.
- Simulation volume is capped at 100,000 generated requests, with intervals
  <=200 and rates <=1000.
- CORS is disabled unless `CWMS_CORS_ORIGINS` lists explicit origins.
- Security headers are set globally.
- Background failures return generic messages while details go to the server log.
- The dashboard keeps an optional token in session storage, not local storage.

## Concurrency and process model

The API is a single Uvicorn process. A run executes in a worker thread through
`asyncio.to_thread` so the event loop stays responsive; progress is published
through a simple in-memory counter. Only one run is active at a time (HTTP 409
otherwise). SQLite uses WAL plus a busy timeout. No distributed workers, queues,
rate limiter, or HA are implemented.

## Trust boundaries

- No user-supplied shell commands are executed.
- Request payloads are validated by Pydantic and `SimulationConfig`.
- Node identifiers are constrained.
- No secrets are stored in the repository; the optional token is read from the
  process environment.
- The shared token is authentication only, not per-user authorization. Do not
  expose this service directly to untrusted networks; use a TLS reverse proxy and
  a real identity layer if that is ever required.
