# Future Azure Integration Plan (NOT EXECUTED)

No Azure resource was created, started, resized, or billed during this project.
The prototype runs entirely locally with synthetic data. This document is a
planning aid for a future, explicitly approved demonstration.

## Preconditions before any billable action

1. Confirm the subscription type, credit balance, quotas, and regional SKU
   availability in the current Azure portal.
2. Verify current pricing for **every** resource: VM compute, managed disk,
   public IP, networking/egress, monitoring/log ingestion, storage, snapshots.
3. Confirm whether stopping/deallocating the VM stops compute billing and which
   resources continue to bill (disks, public IPs, monitoring).
4. Choose a short demo window (for example 1-2 hours) and a dedicated resource
   group with clear names.
5. Configure budget alerts. Treat them as notifications, not hard caps.
6. Obtain explicit approval from the project owner before creating anything.

## Suggested minimal topology (future)

```text
Azure Linux VM (small, disposable)
  |-- CWMS API (uvicorn, bound to localhost or restricted NSG)
  |-- Dashboard 
  `-- SQLite file on the VM disk
Optional: Azure Monitor agent for real CPU/memory metrics
```

## Data-source changes required for real telemetry

The current `Node` model is simulated. A real integration must not reuse the
synthetic load values as if they were measurements. Options:

- Add a metrics adapter that reads real CPU/memory from the OS or Azure Monitor
  and feeds a new `ObservedNode` implementation.
- Keep simulated and observed data in separate fields/endpoints and label the
  source and timestamp on every measurement.
- Do not claim Azure monitoring until an actual agent/API query is verified.

## Safety controls for a demo

- Use a dedicated resource group; delete it afterwards.
- Restrict SSH/HTTP with NSGs; do not expose the API unauthenticated publicly.
- Store no credentials in source, reports, screenshots, or ZIP files.
- Use a temporary SSH key; remove it after the demo.
- Verify the resource group, disks, public IPs, and snapshots are gone after
  cleanup.
- Check Cost Management after the demo.

## Explicit non-goals

- Automatic provisioning or autoscaling.
- Production availability, SLA, or security certification.
- Paid monitoring/logging tiers.
- Multi-region or multi-cloud deployment.

Any cloud action remains blocked until pricing and approval are confirmed.
