﻿# Requirements Traceability

Source documents: `docs/01`-`10` in the supplied document pack. Status reflects
the local prototype only.

## Functional requirements (02_PRD_Requirements.md)

| ID | Requirement | Status | Evidence |
|---|---|---|---|
| FR-01 | Generate/accept synthetic request events | Implemented | `traffic_generator.py`, CLI/API |
| FR-02 | Track per-node count, load, health, latency estimate | Implemented (simulated) | `nodes.py`, `metrics.py` |
| FR-03 | Round-robin distribution | Implemented | `RoundRobinPolicy`, tests |
| FR-04 | Least-loaded distribution | Implemented | `LeastLoadedPolicy`, tests |
| FR-05 | Exclude unhealthy nodes | Implemented | Health-aware policies, tests |
| FR-06 | Request rate over interval | Implemented | Per-interval counts, CSV |
| FR-07 | Surge flag at configured thresholds | Implemented (rate, average load, max node load) | `SurgeDetector`, tests |
| FR-08 | Baseline near-term forecast | Implemented (moving average and change-aware; MA/naive comparison) | `WorkloadForecaster`, tests |
| FR-09 | Rule-based recommendations | Implemented | `RecommendationEngine`, tests |
| FR-10 | CSV export of events and metrics | Implemented | `export_csv`, API export |
| FR-11 | Repeatable normal/burst/failure/overload scenarios | Implemented | Scenarios, seeds, tests |
| FR-12 | Label simulated vs real values | Implemented | Dashboard badge, README, reports |

Additional build-brief items:

| Item | Status | Notes |
|---|---|---|
| FCFS policy | Implemented as extension | `FCFSPolicy` |
| Adaptive/forecast-aware policy | Implemented as extension | `AdaptivePolicy` |
| REST API + dashboard | Implemented | FastAPI + HTML/CSS/JS |
| Bounded admission queues | Implemented | Per-node queue, overflow rejection, configurable threshold/limit |
| Request timeouts | Implemented (simulated) | Queue-wait estimate vs `request_timeout_ms`; timeout counters |
| Persistence | Implemented | SQLite `ResultsStore`, schema v2 + v1 migration + pruning |
| API hardening | Implemented (local scope) | Loopback default, optional bearer token, body/volume limits, opt-in CORS, security headers |
| Multi-seed comparison | Implemented | 4 scenarios x 4 policies x 5 seeds (80 runs, 95% CIs) |

## Non-functional requirements

| ID | Requirement | Status |
|---|---|---|
| NFR-01 | Runs locally on Python 3.10+ without paid services | Met |
| NFR-02 | Modular, readable code | Met |
| NFR-03 | Configurable thresholds | Met |
| NFR-04 | No secrets in source | Met (optional token from environment only) |
| NFR-05 | Reproducible tests and documented limitations | Met (187 tests, browser smoke, documented gaps) |
| NFR-06 | No unsupported production claims | Met (limitations documented) |
| NFR-07 | Safe local defaults and bounded resource use | Met (loopback bind, auth option, body/volume caps) |

## Out of scope (unchanged)

Automatic cloud provisioning, production traffic interception, production
discrete-event queueing, guaranteed autoscaling/zero downtime, Kubernetes,
advanced ML claims, TLS/identity-provider integration, and security
certifications are not implemented. Admission control/rejection and simulated
timeouts are implemented as local extensions, not production SLO guarantees.

## Test-plan scenarios (06_Test_Plan.md)

| ID | Scenario | Covered by |
|---|---|---|
| T01 | Normal steady traffic | `test_normal_scenario_no_surge`, experiment `normal` |
| T02 | Sudden burst | `test_burst_scenario_detects_surge`, experiment `burst` |
| T03 | Unhealthy node | `test_unhealthy_node_receives_no_assignments` |
| T04 | Least-loaded preference | `TestLeastLoaded`, simulator comparison |
| T05 | Policy comparison via CSV | Experiment CSV outputs |
| T06 | Low traffic no alert | `test_no_surge_when_below_threshold` |
| T07 | Forecast stable data | `test_moving_average_value`, change-aware strategy tests |
| T08 | Forecast burst lag | Experiment compares change-aware, MA, and naive errors |
| T09 | No healthy nodes | `test_no_healthy_nodes_rejects_everything` |
| T10 | CSV output | `test_csv_export_columns_and_rows`, API export tests |
| T11 | Queue overflow and timeout accounting | `test_overload_scenario_records_rejections_and_timeouts`, experiment `overload` |
| T12 | Auth/body/bind controls | `TestSecurity`, `test_security_headers_present` |

