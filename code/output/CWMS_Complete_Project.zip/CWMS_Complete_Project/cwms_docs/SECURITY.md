# Security Notes

## Intended use

CWMS is a local, synthetic demonstration. The safe default is:

- bind to `127.0.0.1`;
- no CORS origins;
- no TLS;
- optional shared bearer token for state-changing requests.

It is not an internet-facing service and has no user accounts, roles, audit log,
or rate limiting. If remote access is needed, put it behind a TLS reverse proxy
and an identity-aware gateway.

## Controls in this build

| Control | Behaviour |
|---|---|
| Loopback bind | `run_api.py` defaults to `127.0.0.1` |
| Remote bind guard | Non-loopback host requires `CWMS_API_TOKEN` or explicit `CWMS_ALLOW_UNAUTHENTICATED_REMOTE=1` |
| Bearer auth | `CWMS_API_TOKEN` protects simulation start, scenario run, node health, and history pruning |
| Constant-time compare | Token comparison uses `hmac.compare_digest` |
| Body limit | 32 KiB request-body cap, including chunked requests; returns 413 |
| Volume limit | Intervals <=200, rates <=1000, total generated requests <=100,000 |
| CORS | Disabled by default; explicit `CWMS_CORS_ORIGINS` allowlist only |
| Security headers | `nosniff`, `X-Frame-Options: DENY`, `no-referrer` |
| Error handling | Background failures return generic messages; details go to server logs |
| SQL safety | Parameterised SQLite queries; no dynamic user SQL |
| Input validation | Pydantic and core `SimulationConfig` validation, constrained node names |
| Token storage (UI) | Session storage only; never written into the repository |

## Environment variables

| Variable | Purpose |
|---|---|
| `CWMS_API_HOST` | Bind host; default `127.0.0.1` |
| `CWMS_API_PORT` | Bind port; default `8000` |
| `CWMS_DB_PATH` | SQLite path; default `cwms_data/cwms.db` |
| `CWMS_API_TOKEN` | Optional shared bearer token |
| `CWMS_CORS_ORIGINS` | Optional comma-separated origin allowlist |
| `CWMS_ALLOW_UNAUTHENTICATED_REMOTE` | Emergency override for an isolated demo; keep unset/0 normally |

Use a long random token (for example from a password manager). Never commit a
real token. The API does not load `.env` files automatically.

## Known residual risks

- Bearer auth has no expiry, rotation, per-user identity, or revocation list.
- Requests are not rate-limited; a local process or trusted network peer can
  start repeated runs (bounded only by the one-active-run guard and volume caps).
- No TLS in the app; tokens would cross the network in clear text if exposed
  without a TLS reverse proxy.
- The dashboard token is visible to any script running in the same origin/session.
- SQLite is local and single-writer; WAL improves resilience but is not a
  multi-tenant database.
- Simulation parameters are illustrative, so security/performance results do not
  transfer directly to production.

## Reporting

This is an educational prototype. Do not deploy it as a public service. If it is
adapted for shared use, add TLS termination, an identity provider, per-user
authorization, rate limiting, audit logging, dependency scanning, and a formal
threat review first.
