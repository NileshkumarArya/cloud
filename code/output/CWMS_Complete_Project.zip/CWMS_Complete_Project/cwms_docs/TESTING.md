# Testing Guide

## Environment

- Python 3.10.11 (Windows), standard library + FastAPI/httpx for API tests.
- No database server, Docker, cloud account, or paid service is required.
- Tests use stdlib `unittest`; pytest is not required.
- Browser smoke test is optional and uses Playwright with installed Microsoft
  Edge (`requirements-browser.txt`).

## Commands

```powershell
cd "C:\projects\azure prototype\code"
python -m unittest discover -s cwms_tests -t . -v
node --check cwms_dashboard/app.js
```

Optional browser smoke test:

```powershell
python -m pip install -r requirements-browser.txt
python cwms_scripts/browser_smoke.py
```

Helpers:

```powershell
powershell -File cwms_scripts/run_tests.ps1
```

```bash
bash cwms_scripts/run_tests.sh
```

## Test modules

| File | Coverage |
|---|---|
| `test_nodes.py` | Validation, health, assignment, decay, caps, admission accept/queue/overflow, queue reset, serialization |
| `test_policies.py` | Round robin, least loaded, FCFS, adaptive, saturation tie fairness, factory |
| `test_traffic_generator.py` | Seed reproducibility, burst windows, variation bounds |
| `test_metrics.py` | Counters, rates, queue/timeout accounting, rejection reasons, interval reset, health sync |
| `test_surge_detector.py` | Rate/average/max-load thresholds, priority, cooldown, reset, serialization |
| `test_forecaster.py` | Moving-average/change-aware strategies, causal MAE/RMSE, MA/naive baselines, windowing, boundary/error handling |
| `test_recommendations.py` | Every rule and severity |
| `test_storage.py` | SQLite roundtrip, new admission fields, persistence across instances, ordering, pruning, v1-to-v2 migration |
| `test_simulator.py` | Scenarios, failure handling, equivalence, causality, CSV/JSON, overflow accounting, timeouts, admission-disabled baseline |
| `test_api.py` | Endpoints, validation, persistence, exports, dashboard assets, auth, body limit, CORS, bind guard, volume limit, overload scenario, history pruning |
| `test_dashboard_assets.py` | Static IDs, policy options, theme tokens, asset paths, token control |

API tests use temporary SQLite databases and FastAPI `TestClient`; they do not
touch the development database.

Security tests set `CWMS_API_TOKEN`/CORS/override environment variables and
restore them with `addCleanup` so test order does not leak configuration.

## What the tests do not cover

- Real Azure or real infrastructure telemetry.
- Cross-browser coverage; the optional smoke test uses installed Edge only.
- High-concurrency, multi-process, or long-duration load testing.
- Statistical significance of policy comparisons (five seeds support a
  repeatability check and 95% confidence intervals, not significance testing).
- Real task execution beyond the simulated request/completion model.
- Production queue semantics (the queue drains once per interval; wait is an
  estimate, not a discrete-event simulation).
- TLS, reverse-proxy behaviour, user accounts/roles, rate limiting, or audit
  logging. The optional shared bearer token is covered, not a full auth system.

## Expected result

All 187 unit/integration tests pass locally. The optional browser smoke test
reports `Browser smoke passed: 20 forecast rows rendered`. See
`output/reports/TEST_REPORT.md` for the recorded run, environment versions,
fixed bugs, and not-run items.
